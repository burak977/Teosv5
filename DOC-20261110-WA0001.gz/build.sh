#!/usr/bin/env bash
# Builds the 4.19 kernel for Vestel Venus V5 (TEOS) and packs boot_ci.img
set -euo pipefail
BRANCH="${BRANCH:-lineage-23.2}"
REPO="${REPO:-https://github.com/LineageOS/android_kernel_xiaomi_msm8937}"
ROOT="$PWD"
mkdir -p "$ROOT/artifacts"

git clone --depth 1 --branch "$BRANCH" "$REPO" kernel
cd kernel
echo "== kernel version"; sed -n 1,5p Makefile
git log -1 --format='commit %H %s' | tee "$ROOT/artifacts/kernel-commit.txt"

# optional patches (drivers, dts, fixes) from patches/*.patch
shopt -s nullglob
for p in "$ROOT"/patches/*.patch; do echo "== applying $p"; git apply --verbose "$p"; done

mkdir -p out
cp "$ROOT/kernel.config" out/.config
MK=( O=out ARCH=arm64 CC=clang LD=ld.lld AR=llvm-ar NM=llvm-nm OBJCOPY=llvm-objcopy
     OBJDUMP=llvm-objdump READELF=llvm-readelf STRIP=llvm-strip
     CROSS_COMPILE=aarch64-linux-gnu- CROSS_COMPILE_ARM32=arm-linux-gnueabi-
     CLANG_TRIPLE=aarch64-linux-gnu- KCFLAGS=-Wno-error )

make "${MK[@]}" olddefconfig
cp out/.config "$ROOT/artifacts/used.config"
make "${MK[@]}" -j"$(nproc)" Image.gz 2>&1 | tee "$ROOT/artifacts/build.log"

# the 5 loadable modules (rmnet_perf, rmnet_shs, ...) - non-fatal
make "${MK[@]}" -j"$(nproc)" modules 2>&1 | tee "$ROOT/artifacts/modules.log" || echo "modules build failed (non-fatal)"
mkdir -p "$ROOT/artifacts/modules"
find out -name '*.ko' -exec cp {} "$ROOT/artifacts/modules/" \; || true

cp out/arch/arm64/boot/Image.gz "$ROOT/artifacts/Image.gz"
python3 "$ROOT/pack_boot.py" --header "$ROOT/header.bin" --ramdisk "$ROOT/ramdisk.cpio.gz" \
        --kernel out/arch/arm64/boot/Image.gz --dtb "$ROOT/teos.dtb" --out "$ROOT/artifacts/boot_ci.img"
