#!/usr/bin/env python3
"""Pack an Android boot image (header v0) from header template + kernel(+dtb) + ramdisk."""
import argparse, hashlib, struct
ap = argparse.ArgumentParser()
for a in ("header", "ramdisk", "kernel", "dtb", "out"):
    ap.add_argument("--" + a, required=True)
a = ap.parse_args()
page = 2048
al = lambda x: (x + page - 1) // page * page
hdr = bytearray(open(a.header, "rb").read(page))
assert hdr[:8] == b"ANDROID!", "bad header template"
assert struct.unpack("<I", hdr[36:40])[0] == page
kernel = open(a.kernel, "rb").read() + open(a.dtb, "rb").read()   # Image.gz + appended DTB
rd = open(a.ramdisk, "rb").read()
struct.pack_into("<I", hdr, 8, len(kernel))
struct.pack_into("<I", hdr, 16, len(rd))
struct.pack_into("<I", hdr, 24, 0)  # second size
sha = hashlib.sha1(kernel + struct.pack("<I", len(kernel)) + rd + struct.pack("<I", len(rd)) + struct.pack("<I", 0))
hdr[576:608] = sha.digest() + b"\0" * 12
with open(a.out, "wb") as f:
    f.write(hdr)
    f.write(kernel + b"\0" * (al(len(kernel)) - len(kernel)))
    f.write(rd + b"\0" * (al(len(rd)) - len(rd)))
print("wrote", a.out, "kernel", len(kernel), "ramdisk", len(rd))
