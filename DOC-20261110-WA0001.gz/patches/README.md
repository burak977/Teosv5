Put *.patch files here (git diff / git format-patch output made against the chosen kernel branch).
They are applied in alphabetical order before building. Example names: 0001-hall-switch.patch
