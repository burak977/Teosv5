Vestel Venus V5 (TEOS) kernel CI assets
 - kernel.config : config extracted from the working boot_teos_v2_display.img (4.19.325)
 - header.bin    : boot image header template (cmdline, addresses) from the same image
 - ramdisk.cpio.gz : ramdisk from the same image
 - teos.dtb      : patched DTB (v4: PMI8950 WLED/lab/ibb + touch rails)
 - pack_boot.py, build.sh : used by the workflow
